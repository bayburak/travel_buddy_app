package mypackage.utils;

public class Validator {
    
}
