package mypackage.controller;

public class MapController {
    
}
