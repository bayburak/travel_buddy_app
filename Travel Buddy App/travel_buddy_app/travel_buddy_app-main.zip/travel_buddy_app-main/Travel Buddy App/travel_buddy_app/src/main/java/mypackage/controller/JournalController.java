package mypackage.controller;

public class JournalController {
    
}
