package mypackage.controller;

public class AuthController {
    
}
