package mypackage.utils;

public class Vadidator {
    
}
