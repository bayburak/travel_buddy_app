package mypackage.controller;

public class FindBuddyController {
    
}
