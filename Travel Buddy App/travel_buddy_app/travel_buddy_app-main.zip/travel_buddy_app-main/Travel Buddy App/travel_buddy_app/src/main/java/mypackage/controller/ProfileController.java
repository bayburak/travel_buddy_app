package mypackage.controller;

public class ProfileController {
    
}
